<?php
      $servername = "localhost";
      $dbusername = "yourusername";
      $dbpassword = "yourpassword";
      $dbname = "DatasetEntryForm";
?>
